Exercise 13 - Porting CUDA to OpenCL
====================================
