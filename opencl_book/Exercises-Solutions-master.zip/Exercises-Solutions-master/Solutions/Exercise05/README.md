Exercise 5 - The D = A + B + C problem
======================================
