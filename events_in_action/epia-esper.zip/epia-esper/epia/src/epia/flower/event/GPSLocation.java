/**************************************************************************************
 * The software in this package is published under the terms of the GPL license       *
 * a copy of which has been included with this distribution in the license.txt file.  *
 **************************************************************************************/
package epia.flower.event;

public class GPSLocation {
	
	private String driver;
	
	private Point location;

	public GPSLocation() {
		super();
	}

	public GPSLocation(String driver, Point location) {
		super();
		this.driver = driver;
		this.location = location;
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public Point getLocation() {
		return location;
	}

	public void setLocation(Point location) {
		this.location = location;
	}
	
	

}
