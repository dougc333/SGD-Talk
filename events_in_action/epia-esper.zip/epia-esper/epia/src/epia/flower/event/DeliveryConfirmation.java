/**************************************************************************************
 * The software in this package is published under the terms of the GPL license       *
 * a copy of which has been included with this distribution in the license.txt file.  *
 **************************************************************************************/
package epia.flower.event;

public class DeliveryConfirmation {

	private int requestId;
	
	private String driver;

	public DeliveryConfirmation() {
		super();
	}

	public DeliveryConfirmation(int requestId, String driver) {
		super();
		this.requestId = requestId;
		this.driver = driver;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}
	
	
}
