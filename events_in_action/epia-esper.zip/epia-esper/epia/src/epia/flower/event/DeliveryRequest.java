/**************************************************************************************
 * The software in this package is published under the terms of the GPL license       *
 * a copy of which has been included with this distribution in the license.txt file.  *
 **************************************************************************************/
package epia.flower.event;

public class DeliveryRequest {
	
	private int requestId;
	
	private String store;
	
	private Point location;
	
	private long pickupTime;
	
	private long deliveryTime;
	
	private int minimumRanking;
	
	public DeliveryRequest() {
		super();
	}

	public DeliveryRequest(int requestId, String store, Point location,
			long pickupTime, long deliveryTime, int minimumRanking) {
		super();
		this.requestId = requestId;
		this.store = store;
		this.location = location;
		this.pickupTime = pickupTime;
		this.deliveryTime = deliveryTime;
		this.minimumRanking = minimumRanking;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getStore() {
		return store;
	}

	public void setStore(String store) {
		this.store = store;
	}

	public Point getLocation() {
		return location;
	}

	public void setLocation(Point location) {
		this.location = location;
	}

	public long getPickupTime() {
		return pickupTime;
	}

	public void setPickupTime(long pickupTime) {
		this.pickupTime = pickupTime;
	}

	public long getDeliveryTime() {
		return deliveryTime;
	}

	public void setDeliveryTime(long deliveryTime) {
		this.deliveryTime = deliveryTime;
	}

	public int getMinimumRanking() {
		return minimumRanking;
	}

	public void setMinimumRanking(int minimumRanking) {
		this.minimumRanking = minimumRanking;
	}
	
	

}
