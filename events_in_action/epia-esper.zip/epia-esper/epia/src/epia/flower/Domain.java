/**************************************************************************************
 * The software in this package is published under the terms of the GPL license       *
 * a copy of which has been included with this distribution in the license.txt file.  *
 **************************************************************************************/
package epia.flower;

import java.util.HashMap;
import java.util.Map;

public class Domain {
	
	private static int driverRank(String driver) {
		return driver.length();
	}

	public static Map driverRankLookup(String driver) {
		Map result = new HashMap(1);
		result.put("ranking", driverRank(driver));
		return result;
	}
	
	public static Map<String, Class> driverRankLookupMetadata() {
	    Map<String, Class> propertyNames = new HashMap<String, Class>();
	    propertyNames.put("ranking", int.class);
	    return propertyNames;
	}

	private static boolean isStoreManual(String store) {
		return store.toLowerCase().indexOf("manual")>=0;
	}

	public static Map isStoreManualLookup(String store) {
		Map result = new HashMap(1);
		result.put("manual", isStoreManual(store));
		return result;
	}
	
	public static Map<String, Class> isStoreManualLookupMetadata() {
	    Map<String, Class> propertyNames = new HashMap<String, Class>();
	    propertyNames.put("manual", boolean.class);
	    return propertyNames;
	  }
	
}
