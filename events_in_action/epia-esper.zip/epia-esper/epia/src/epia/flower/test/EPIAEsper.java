/**************************************************************************************
 * The software in this package is published under the terms of the GPL license       *
 * a copy of which has been included with this distribution in the license.txt file.  *
 **************************************************************************************/
package epia.flower.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import com.espertech.esper.client.Configuration;
import com.espertech.esper.client.EPOnDemandQueryResult;
import com.espertech.esper.client.EPRuntime;
import com.espertech.esper.client.EPServiceProvider;
import com.espertech.esper.client.EPServiceProviderManager;
import com.espertech.esper.client.EPStatement;
import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;
import com.espertech.esper.client.time.CurrentTimeEvent;
import com.espertech.esper.client.util.EventRenderer;
import com.espertech.esper.client.util.JSONEventRenderer;
import com.espertech.esperio.Adapter;
import com.espertech.esperio.AdapterCoordinator;
import com.espertech.esperio.AdapterCoordinatorImpl;
import com.espertech.esperio.AdapterInputSource;
import com.espertech.esperio.csv.CSVInputAdapter;
import com.espertech.esperio.csv.CSVInputAdapterSpec;
import com.sun.xml.internal.messaging.saaj.packaging.mime.util.LineInputStream;

import epia.flower.event.DeliveryBid;
import epia.flower.event.DeliveryConfirmation;
import epia.flower.event.DeliveryRequest;
import epia.flower.event.GPSLocation;
import epia.flower.event.PickUpConfirmation;
import epia.flower.event.Point;

/**
 * "Event Processing In Action" sample application
 * 
 * A simulator that loads the etc/epia.epl file
 * and provides basic command line interface to simulate scenarios from flat CSV files
 * 
 * @author Alexandre Vasseur
 */
public class EPIAEsper implements UpdateListener {

	public static long START_TIME = System.currentTimeMillis();

	private EPServiceProvider engine;
	private int reqId = 0;
	
	private EPIAEsper() {
		Configuration c = new Configuration();
		c.configure("esper.cfg.xml");//lookup in classpath
		engine = EPServiceProviderManager.getProvider("epia", c);
	}
	
	public static void main(String args[]) {
		EPIAEsper example = new EPIAEsper();
		example.deploy("etc/epia.epl");
		example.attachConsoleOutput();
		String usage = "> Ready.\n" +
		"	q:quit\n" +
		"	s:status\n" +
		//"	t:test\n" +
		"	d:run ./data files in a coordinated way for GPSLocation.csv, DeliveryRequest.csv and DeliveryBid.csv\n" +
		"	pc <driverId> <requestId> <store>: simulate a Pickup Confirmation\n" +
		"	dc <driverId> <requestId>: simulate a Delivery Confirmation\n" +
		"	@ <EventType> <file.csv>: run the given data file from ./data folder, assuming it contains events of type <EventType>" +
		"	+ <x>: adjust time from x more seconds\n" +
		"	? <query>: execute the given query\n" +
		"	help\n" +
		">";
		try {
			System.out.println(usage);
			BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
			for (String l = stdin.readLine(); true; l = stdin.readLine()) {
				try {
					if ("q".equals(l)) {
						System.exit(0);
					} else if ("s".equals(l)) {
						example.status();
	//				} else if ("t".equals(l)) {
	//					System.out.println("> Running with some simple test data");
	//					example.test();
					} else if ("d".equals(l)) {
						System.out.println("> Running from data files");
						example.loadCoordinatedDataFiles();
					} else if (l.startsWith("@")) {
						System.out.println("> Running from data file " + l);
						example.loadDataFile(l.substring(1).trim());
					} else if (l.startsWith("+")) {
						example.advance(Long.parseLong(l.substring(1).trim()));
					} else if (l.startsWith("?")) {
						example.query(l.substring(1));
					} else if (l.startsWith("pc")) {
						example.pc(l.substring(2).trim());
					} else if (l.startsWith("dc")) {
						example.dc(l.substring(2).trim());
					} else {
						System.out.println(usage);
					}
				} catch (Throwable t) {
					System.err.println("ERROR" + t.getMessage());
					t.printStackTrace();
					System.out.println("\n>");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void pc(String l) {
		String[] tokens = l.split(" ");
		PickUpConfirmation pc = new PickUpConfirmation(
				Integer.parseInt(tokens[1]),
				tokens[2],
				tokens[0]
		);
		engine.getEPRuntime().sendEvent(pc);
	}
	
	public void dc(String l) {
		String[] tokens = l.split(" ");
		DeliveryConfirmation dc = new DeliveryConfirmation(
				Integer.parseInt(tokens[0]),
				tokens[1]
		);
		engine.getEPRuntime().sendEvent(dc);
	}

	public void advance(long l) {
		engine.getEPRuntime().sendEvent(new CurrentTimeEvent(engine.getEPRuntime().getCurrentTime() + l * 1000));
		log("Now at t+" + engineMillis()+ " sec");
	}
	
	public void query(String q) {
		EPOnDemandQueryResult r = engine.getEPRuntime().executeQuery(q);
		for (EventBean e : r.getArray()) {
			JSONEventRenderer o = engine.getEPRuntime().getEventRenderer().getJSONRenderer(e.getEventType());
			log(o.render("", e));
		}
	}
	
	public void status() {
		log("STATUS t+" + engineMillis()+ " sec");
		log("-- GPSLocation");
		EPOnDemandQueryResult r = engine.getEPRuntime().executeQuery("select * from GPSLocationW");
		for (EventBean e : r.getArray()) {
			JSONEventRenderer o = engine.getEPRuntime().getEventRenderer().getJSONRenderer(e.getEventType());
			log(o.render("GPSLocation", e));
		}
		log("-- DeliveryBid");
		EPOnDemandQueryResult r1 = engine.getEPRuntime().executeQuery("select * from DeliveryBidW");
		for (EventBean e : r1.getArray()) {
			JSONEventRenderer o = engine.getEPRuntime().getEventRenderer().getJSONRenderer(e.getEventType());
			log(o.render("DeliveryBid", e));
		}
		log("-- AlertW");
		EPOnDemandQueryResult r2 = engine.getEPRuntime().executeQuery("select * from AlertW");
		for (EventBean e : r2.getArray()) {
			JSONEventRenderer o = engine.getEPRuntime().getEventRenderer().getJSONRenderer(e.getEventType());
			log(o.render("AlertW", e));
		}
	}
		
	//--- EsperIO CSV input file methods
	
	public void loadDataFile(String eventTypeDataFile) {
		String[] tokens = eventTypeDataFile.split(" ");
		File f = new File("data/"+tokens[1]);
		AdapterInputSource source1 = new AdapterInputSource(f);
		CSVInputAdapterSpec input1 = new CSVInputAdapterSpec(source1, tokens[0]);
		input1.setTimestampColumn("timestamp");
	
		AdapterCoordinator coordinator = new AdapterCoordinatorImpl(engine, false, true);
		coordinator.coordinate(new CSVInputAdapter(input1));
		coordinator.start();
	}
	
	public void loadCoordinatedDataFiles() {
		AdapterInputSource source1 = new AdapterInputSource(new File("data/GPSLocation.csv"));
		CSVInputAdapterSpec input1 = new CSVInputAdapterSpec(source1, "GPSLocation");
		input1.setTimestampColumn("timestamp");

		AdapterInputSource source2 = new AdapterInputSource(new File("data/DeliveryRequest.csv"));
		CSVInputAdapterSpec input2 = new CSVInputAdapterSpec(source2, "DeliveryRequest");
		input2.setTimestampColumn("timestamp");

		AdapterInputSource source3 = new AdapterInputSource(new File("data/DeliveryBid.csv"));
		CSVInputAdapterSpec input3 = new CSVInputAdapterSpec(source3, "DeliveryBid");
		input3.setTimestampColumn("timestamp");
		
		AdapterCoordinator coordinator = new AdapterCoordinatorImpl(engine, false, true);
		coordinator.coordinate(new CSVInputAdapter(input1));
		coordinator.coordinate(new CSVInputAdapter(input2));
		coordinator.coordinate(new CSVInputAdapter(input3));
		coordinator.start();
	}
		
	//--- utility methods
	
	/**
	 * This utility method loads an EPL file into the engine by considering semicolon as an EPL separator
	 */
	public void deploy(String eplFile) {
		try {
			LineInputStream r = new LineInputStream(new FileInputStream(eplFile));
			StringBuffer sb = new StringBuffer();
			for (String line = r.readLine(); line != null; line = r.readLine()) {
				sb.append(line).append('\n');
				if (line.trim().endsWith(";")) {
					String epl = sb.toString();
					epl = epl.trim();
					epl = epl.substring(0, epl.length()-1);
					sb = new StringBuffer();
					
					try {
						EPStatement s = engine.getEPAdministrator().createEPL(epl);
						log("registered - "  + s.getName());
					} catch (Throwable t) {
						log("FAILED - " + t.getMessage() + "\n[" + epl + "]");
					}
				}
			}
			r.close();
		} catch (IOException e) {
			log("ERROR - " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	public static void log(Object o) {
		System.out.println(o);
	}

	public void attachConsoleOutput() {
		//engine.getEPAdministrator().createEPL("select * from DeliveryRequest").addListener(this);
		engine.getEPAdministrator().createEPL("select * from BidRequest").addListener(this);
		engine.getEPAdministrator().createEPL("select * from Assignment").addListener(this);
		engine.getEPAdministrator().createEPL("select * from AlertW").addListener(this);
	}

	public void update(EventBean[] newEvents, EventBean[] oldEvents) {
            StringBuffer sb = new StringBuffer();
            sb.append("t+").append(engineMillis()).append(" [").append(Thread.currentThread().getName()).append("] (");
            sb.append("").append(") ");
            if (newEvents != null) sb.append("newEvents # ").append(newEvents.length).append(", ");
            if (oldEvents != null) sb.append("oldEvents # ").append(oldEvents.length);
            sb.append("\n");

            if (newEvents != null) {
	            for (int i = 0; i < newEvents.length; i++) {
	                EventBean newEvent = newEvents[i];
	                sb.append("+ " + newEvent.getEventType().getName() + " { ");
	                boolean first = true;
	                for (String prop : newEvent.getEventType().getPropertyNames()) {
	                	if (!first) sb.append(", ");
	                	sb.append(prop).append(" = ").append(newEvent.get(prop));
	                	first = false;
	                }
	                sb.append(" }");
	            }
            }
            System.err.println(sb);
	}
	
	public long engineMillis() {
	    return engine.getEPRuntime().getCurrentTime();
	}

	public void test() {
		EPRuntime r = engine.getEPRuntime();
		r.sendEvent(new CurrentTimeEvent(System.currentTimeMillis()));
		
		// two drivers
		r.sendEvent(new GPSLocation("driver_1", new Point(0, 0)));
		r.sendEvent(new GPSLocation("driver_2", new Point(1, 1)));
		
		// one request nearby driver_1
		long now = System.currentTimeMillis();
		r.sendEvent(new DeliveryRequest(++reqId, "storeAuto", new Point(0.000001, 0.000001), now+300*1000, now+600*1000, 0));
		// should create a BidRequest

		// driver_1 answers back
		r.sendEvent(new DeliveryBid(reqId, "storeAuto", "driver_1", now+200*1000));
		// should create an assignment after 120sec
		r.sendEvent(new CurrentTimeEvent(engineMillis()+120*1000));

		// one request too far from drivers
		r.sendEvent(new DeliveryRequest(++reqId, "storeAuto", new Point(0.5, 0.5), now+300*1000, now+600*1000, 0));
		
		// can now wait for alerts to trigger
		r.sendEvent(new CurrentTimeEvent(engineMillis()+300*1000));
		r.sendEvent(new CurrentTimeEvent(engineMillis()+300*1000));
	}
	

}
