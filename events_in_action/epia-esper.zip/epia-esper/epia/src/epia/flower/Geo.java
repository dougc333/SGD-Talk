/**************************************************************************************
 * The software in this package is published under the terms of the GPL license       *
 * a copy of which has been included with this distribution in the license.txt file.  *
 **************************************************************************************/
package epia.flower;

import epia.flower.event.Point;

public class Geo {

	public static double distanceKM(Point from, Point to) {
		double earthRadius = 3958.75D;
        double dLat = Math.toRadians(to.getLat() - from.getLat());
        double dLng = Math.toRadians(to.getLng() - from.getLng());
        double a = Math.sin(dLat / 2D) * Math.sin(dLat / 2D) + Math.cos(Math.toRadians(from.getLat())) * Math.cos(Math.toRadians(to.getLat())) * Math.sin(dLng / 2D) * Math.sin(dLng / 2D);
        double c = 2D * Math.atan2(Math.sqrt(a), Math.sqrt(1.0D - a));
        double dist = earthRadius * c;
        int meterConversion = 1609;
        double resultMeters = dist * (double)meterConversion;
        return (new Float(resultMeters / 1000D)).floatValue();
		//return 8;
	}
}
