/**************************************************************************************
 * The software in this package is published under the terms of the GPL license       *
 * a copy of which has been included with this distribution in the license.txt file.  *
 **************************************************************************************/

"Event Processing In Action"
Sample application implemented with Esper
Author: Alexandre Vasseur - all rights reserved.
 
** Introduction
 
This sample application implements the primary use cases described in the EPIA book "Fast Flower Delivery".
The primary goal is to illustrate how the book application can be implemented using Esper' EPL event processing language
and how one can articulate this for a minimal running application for test purpose.
 
You should be familiar with the EPIA sample application scenarios as described in the book or book PDF excerpt available from
- Event Processing Technical Society - EPTS - http://www.ep-ts.com/content/view/74/108/

You should be familiar with Esper. A good place to to start exploring the various features is to read introduction available from:
- http://esper.codehaus.org
- http://esper.codehaus.org/tutorials/tutorial/tutorial.html
- http://esper.codehaus.org/tutorials/tutorial/quickstart.html
- http://coffeeonesugar.wordpress.com/2009/07/21/getting-started-with-esper-in-5-minutes/
- http://onjava.com/pub/a/onjava/2007/03/07/esper-event-stream-processing-and-correlation.html (this last article has some sample code as well)
and slides from:
- http://esper.codehaus.org/tutorials/tutorial/presentations.html
- http://dist.codehaus.org/esper/NYJavaSIG_May_30_2007.pdf

The reference documentation is available from below as html or pdf
http://esper.codehaus.org/esper/documentation/documentation.html


** Design decisions
 
Input events such as GPSLocation, DeliveryRequest, DeliveryBid are represented as Java POJO events.
PickUpConfirmation and DeliveryConfirmation are also represented as Java POJO events. 
Note that Esper also supports Map based or XML based event type.
 
Those events contain a null-arg constructor to allow for EsperIO/CSV to instantiate events from rows read from flat CSV files
for sample data purpose.
 
The file etc/epia.epl contains the entire event processing related logic for the primary scenarios:
- joining GPSLocation with DeliveryRequest
- joining DeliveryRequest and DeliveryBid to create Assignment
- tracking Assignment to generate Alerts as needed
The driver scoring is left as an exercised. Refer to the etc/epia.epl comments for more details.
 
The domain model, such as knowing each driver ranking, if a store is configured for manual or auto assignment
is implemented in the epia.flower.Domain class and Esper EPL etc/epia.epl demonstrate its integration.
Currently:
- driver ranking = driver name length
- store is manual if the store name contains "manual"
Note that Esper also supports integration of streaming data with data from relational database.   

** Prerequisites

- Java JDK 6
- Esper 3.3.0 including EsperIO/CSV 3.3.0 

TODO fix when Esper 3.3.0 is GA
This sample application relies on Esper 3.3.0 features.
Esper 3.3.0 is NOT GA YET and an early access version is provided in lib/ for now.
(support for "on .. update" and few bug fixes)

- One can open the provided application on any Java IDE.
The ./lib are the project binary dependencies inherited from Esper.

An ant script is also provided for convenience.
If you have Ant installed, type "ant" to do a full clean, compile and run.

** How to run

The sample application can be run on command line or from the IDE (once compiled)
The main class is "epia.flower.test.EPIAEsper" and takes no argument.
The classpath must be all jars from ./lib and also the ./etc folder.
The application must be run in the project folder so as to have ./data relative to its working directory.

A basic command line interface is provided, and some simple example input data files are provided:
A typical usage scenario could be:

	> Ready.
		q:quit
		s:status
		d:run ./data files in a coordinated way for GPSLocation.csv, DeliveryRequest.csv and DeliveryBid.csv
		pc <driverId> <requestId> <store>: simulate a Pickup Confirmation
		dc <driverId> <requestId>: simulate a Delivery Confirmation
		@ <EventType> <file.csv>: run the given data file from ./data folder, assuming it contains events of type <EventType>	+ <x>: adjust time from x more seconds
		? <query>: execute the given query
		help

	> s
	// should show that there are no drivers and no delivery bid or requests or alerts

	> d
	// will load 2 drivers and will start a delivery bid for the nearby driver_1

	> + 120
	// will trigger the assignment phase
	// some trace showing that an assignment has been made for requestId 1 should appear
	
	//... one can issue "+ xxx" commands
	// to observe various Alerts (no pickup)
	
	> pc driver_1 1 store_1
	// this simulates a PickUpConfirmation
	
	//... one can issue "+ xxx" commands
	// to observe various Alerts (no delivery)

** About the data files

The ./data folder contains CSV formatted flat file. Those files are sample input data that can be use for a simulation,
using the 'd' or the '@ <EventType> <file.csv>' on the command prompt.

Each file can only contain one event type. The first row is a header row, that maps the defined event type properties.
Comments can appear in the file using a '# ...' syntax.
Other rows are events that will be sent as input to the engine.
The 'timestamp' column is a specific one used to coordinate events (when using 'd' on the command prompt).
If 'timestamp' is set to '0', the actual engine time will be used.     

By writing such files, with a combination of '@ <EventType> <file.csv>' and '+ xxx' commands on the command prompt, one
can simulate any kind of scenarios.

Note that the underlying feature is provided as part of EsperIO and its CSV input adapter.
http://esper.codehaus.org/esper/documentation/documentation.html

** Limitations

The provided implementation does not implement "Phase 4 - Ranking Evaluation" and "Phase 5 - Activity Monitoring".
Those are left as an exercise to the reader.
- Phase 4 would be best implemented by tracking the delivery count per driver, and performing aggregate on a traditional relational database that would keep track of the entire
delivery history - which seems more a realistic implementation than doing it with only an event processing platform.
- Phase 5 would be best implemented on the same basis, possibly using the event processing platform only as a triggering mechanism.

Esper Enterprise Edition and possibly EsperJDBC may be better implementation choices for a real world implementation, especially if there are graphical requirements for activity monitoring.
Our reader can learn more about Esper Enterprise Edition at
- General product description: http://www.espertech.com/products/esperee.php
- Demos: http://www.espertech.com/resources/




 

 
