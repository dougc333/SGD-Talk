// Placeholder to make it easier to implement l10n in the future (make is searchable)
export default function t1(x: string): string {
  return x;
}
