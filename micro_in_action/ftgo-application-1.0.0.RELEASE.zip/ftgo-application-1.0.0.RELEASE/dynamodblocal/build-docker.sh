docker build -t test-dynamodblocal .
