package net.chrisrichardson.ftgo.common;

public class NotYetImplementedException extends RuntimeException {
}
