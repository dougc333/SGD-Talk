package net.chrisrichardson.ftgo.orderservice.api;

public class OrderServiceChannels {
  public static final String orderServiceChannel = "orderService";
}
