package net.chrisrichardson.ftgo.orderservice.api.events;

import io.eventuate.tram.events.common.DomainEvent;

public interface OrderDomainEvent extends DomainEvent {
}
