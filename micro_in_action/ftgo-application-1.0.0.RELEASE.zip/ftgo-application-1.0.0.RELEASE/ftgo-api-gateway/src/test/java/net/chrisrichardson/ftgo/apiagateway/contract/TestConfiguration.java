package net.chrisrichardson.ftgo.apiagateway.contract;

import org.springframework.context.annotation.Configuration;

@Configuration
public class TestConfiguration {

}
