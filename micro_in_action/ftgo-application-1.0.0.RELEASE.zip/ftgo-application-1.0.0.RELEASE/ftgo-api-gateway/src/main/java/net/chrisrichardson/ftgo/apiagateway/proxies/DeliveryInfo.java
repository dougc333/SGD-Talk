package net.chrisrichardson.ftgo.apiagateway.proxies;

public class DeliveryInfo {
}
