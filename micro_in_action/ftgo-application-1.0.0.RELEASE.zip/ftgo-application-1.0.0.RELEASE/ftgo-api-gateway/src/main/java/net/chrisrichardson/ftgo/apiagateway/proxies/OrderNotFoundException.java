package net.chrisrichardson.ftgo.apiagateway.proxies;

public class OrderNotFoundException extends RuntimeException {
  public OrderNotFoundException() {
  }
}
