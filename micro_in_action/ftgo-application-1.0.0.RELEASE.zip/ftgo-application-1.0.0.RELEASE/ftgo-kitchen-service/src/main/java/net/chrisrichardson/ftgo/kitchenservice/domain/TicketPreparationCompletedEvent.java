package net.chrisrichardson.ftgo.kitchenservice.domain;

public class TicketPreparationCompletedEvent implements TicketDomainEvent {
}
