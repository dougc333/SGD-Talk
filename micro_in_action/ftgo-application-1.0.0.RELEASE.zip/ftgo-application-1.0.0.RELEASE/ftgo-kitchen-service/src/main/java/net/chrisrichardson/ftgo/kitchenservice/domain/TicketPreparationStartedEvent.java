package net.chrisrichardson.ftgo.kitchenservice.domain;

public class TicketPreparationStartedEvent implements TicketDomainEvent {
}
