package net.chrisrichardson.ftgo.kitchenservice.domain;

public class TicketCancelled implements TicketDomainEvent {
}
