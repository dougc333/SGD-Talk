package net.chrisrichardson.ftgo.kitchenservice.domain;

public class RestaurantDetailsVerificationException extends RuntimeException {
}
