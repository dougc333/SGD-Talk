package net.chrisrichardson.ftgo.kitchenservice.domain;

public class TicketPickedUpEvent implements TicketDomainEvent {
}
