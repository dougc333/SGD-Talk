package net.chrisrichardson.ftgo.kitchenservice.domain;

import io.eventuate.tram.events.common.DomainEvent;

public interface TicketDomainEvent extends DomainEvent {
}
