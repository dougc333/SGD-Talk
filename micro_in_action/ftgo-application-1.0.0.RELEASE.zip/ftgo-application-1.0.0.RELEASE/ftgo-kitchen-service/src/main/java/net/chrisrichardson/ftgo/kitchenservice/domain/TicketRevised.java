package net.chrisrichardson.ftgo.kitchenservice.domain;


public class TicketRevised implements TicketDomainEvent {
}
