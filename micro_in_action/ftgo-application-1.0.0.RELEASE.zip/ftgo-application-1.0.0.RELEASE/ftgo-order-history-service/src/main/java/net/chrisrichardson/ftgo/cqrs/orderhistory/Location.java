package net.chrisrichardson.ftgo.cqrs.orderhistory;

public class Location {
}
