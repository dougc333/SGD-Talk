package net.chrisrichardson.ftgo.cqrs.orderhistory.dynamodb;

public enum DeliveryStatus {
  PICKED_UP
}
