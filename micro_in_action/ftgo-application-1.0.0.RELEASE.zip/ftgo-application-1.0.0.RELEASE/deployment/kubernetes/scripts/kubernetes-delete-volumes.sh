#! /bin/bash -e

kubectl delete pvc ftgo-dynamodb-persistent-storage-ftgo-dynamodb-local-0  ftgo-kafka-persistent-storage-ftgo-kafka-0  ftgo-mysql-persistent-storage-ftgo-mysql-0 ftgo-zookeeper-persistent-storage-ftgo-zookeeper-0

