#! /bin/bash -e

docker build -t test-eventuateio-local-mysql .
