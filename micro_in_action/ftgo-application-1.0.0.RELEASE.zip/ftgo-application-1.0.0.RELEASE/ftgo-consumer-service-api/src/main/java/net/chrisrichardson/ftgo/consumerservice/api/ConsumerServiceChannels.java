package net.chrisrichardson.ftgo.consumerservice.api;

public class ConsumerServiceChannels {
  public static final String consumerServiceChannel = "consumerService";
}
