package net.chrisrichardson.ftgo.kitchenservice.api;

public class KitchenServiceChannels {
  public static final String kitchenServiceChannel = "kitchenService";
}
