package net.chrisrichardson.ftgo.accountservice.api;


public class AccountingServiceChannels {

  public static String accountingServiceChannel = "accountingService";

}
