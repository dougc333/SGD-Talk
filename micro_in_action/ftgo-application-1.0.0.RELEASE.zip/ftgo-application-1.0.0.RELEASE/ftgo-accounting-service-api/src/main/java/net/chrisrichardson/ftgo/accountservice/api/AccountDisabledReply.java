package net.chrisrichardson.ftgo.accountservice.api;

public class AccountDisabledReply {
}
