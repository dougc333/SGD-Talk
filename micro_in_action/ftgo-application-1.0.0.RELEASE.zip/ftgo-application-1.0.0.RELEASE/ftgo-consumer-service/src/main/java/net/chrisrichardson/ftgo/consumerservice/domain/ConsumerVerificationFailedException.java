package net.chrisrichardson.ftgo.consumerservice.domain;

public class ConsumerVerificationFailedException extends RuntimeException {
}
