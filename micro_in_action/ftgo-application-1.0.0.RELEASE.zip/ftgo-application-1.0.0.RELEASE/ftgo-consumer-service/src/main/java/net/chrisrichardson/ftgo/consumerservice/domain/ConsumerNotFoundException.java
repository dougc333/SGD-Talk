package net.chrisrichardson.ftgo.consumerservice.domain;

public class ConsumerNotFoundException extends ConsumerVerificationFailedException {
}
