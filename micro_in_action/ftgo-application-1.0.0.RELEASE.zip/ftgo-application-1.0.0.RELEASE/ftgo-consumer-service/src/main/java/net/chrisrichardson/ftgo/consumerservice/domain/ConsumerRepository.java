package net.chrisrichardson.ftgo.consumerservice.domain;

import org.springframework.data.repository.CrudRepository;

public interface ConsumerRepository extends CrudRepository<Consumer, Long> {
}
