package net.chrisrichardson.ftgo.accountingservice.domain;

public class AccountDisabledException extends RuntimeException {
}
