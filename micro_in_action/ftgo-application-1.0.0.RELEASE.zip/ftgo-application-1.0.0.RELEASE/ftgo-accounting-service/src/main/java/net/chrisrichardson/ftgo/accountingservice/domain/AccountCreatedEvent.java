package net.chrisrichardson.ftgo.accountingservice.domain;

import io.eventuate.Event;

public class AccountCreatedEvent implements Event {
}
