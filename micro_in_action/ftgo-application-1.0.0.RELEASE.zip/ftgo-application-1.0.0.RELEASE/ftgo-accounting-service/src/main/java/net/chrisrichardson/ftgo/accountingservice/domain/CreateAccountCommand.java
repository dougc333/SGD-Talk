package net.chrisrichardson.ftgo.accountingservice.domain;

public class CreateAccountCommand implements AccountCommand {
}
