package net.chrisrichardson.ftgo.accountingservice.domain;

import io.eventuate.Command;

public interface AccountCommand extends Command {
}
