package net.chrisrichardson.ftgo.accountingservice.domain;

import io.eventuate.Event;

public class AccountAuthorizationFailed implements Event {
}
