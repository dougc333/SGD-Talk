#! /bin/bash -e

docker build -t test-dynamodblocal-init .
