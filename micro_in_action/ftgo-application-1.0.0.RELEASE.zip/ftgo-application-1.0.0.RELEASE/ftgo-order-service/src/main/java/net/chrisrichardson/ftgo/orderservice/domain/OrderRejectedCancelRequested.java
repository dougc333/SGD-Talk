package net.chrisrichardson.ftgo.orderservice.domain;

public class OrderRejectedCancelRequested {
}
