package net.chrisrichardson.ftgo.orderservice.domain;

public class OptimisticOfflineLockException extends RuntimeException {

}
