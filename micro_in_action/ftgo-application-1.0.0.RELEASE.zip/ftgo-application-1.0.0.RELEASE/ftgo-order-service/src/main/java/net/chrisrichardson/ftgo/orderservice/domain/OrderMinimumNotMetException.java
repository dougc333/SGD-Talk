package net.chrisrichardson.ftgo.orderservice.domain;

public class OrderMinimumNotMetException extends RuntimeException {
}
