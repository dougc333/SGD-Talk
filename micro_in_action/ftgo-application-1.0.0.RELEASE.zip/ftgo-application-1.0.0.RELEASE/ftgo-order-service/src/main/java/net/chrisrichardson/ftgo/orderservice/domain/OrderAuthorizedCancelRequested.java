package net.chrisrichardson.ftgo.orderservice.domain;

import io.eventuate.tram.events.common.DomainEvent;

public class OrderAuthorizedCancelRequested implements DomainEvent {
}
