# React Grid

Data grid for [React][].

## Credits

React Grid is free software created by [Prometheus Research][] and is released
under the MIT.

[React]: http://facebook.github.io/react/
[Prometheus Research, LLC]: http://prometheusresearch.com
