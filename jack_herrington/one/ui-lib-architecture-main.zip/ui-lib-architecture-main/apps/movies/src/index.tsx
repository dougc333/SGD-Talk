import("./bootstrap");

export default true;
