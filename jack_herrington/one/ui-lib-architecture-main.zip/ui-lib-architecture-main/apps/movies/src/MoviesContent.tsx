import React from "react";
import { MoviesContent } from "movies-content";
export default MoviesContent;
