import React from "react";
import MoviesContent from "./MoviesContent";

export { MoviesContent };
