module.exports = function(data) {
  return `
<footer>
  <p>
    Made with
    <a href="https://github.com/PolymerLabs/lit-element-starter-ts">lit-element-starter-ts</a>
  </p>
</footer>`;
};
