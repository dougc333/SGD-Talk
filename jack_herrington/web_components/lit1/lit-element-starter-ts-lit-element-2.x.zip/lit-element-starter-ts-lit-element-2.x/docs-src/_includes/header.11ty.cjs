module.exports = function(data) {
  return `
<header>
  <h1>&lt;my-element></h1>
  <h2>A web component just for me.</h2>
</header>`;
};
