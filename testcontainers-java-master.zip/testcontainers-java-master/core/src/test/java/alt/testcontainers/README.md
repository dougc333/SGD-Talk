Useful place for running tests that need to be outside of the `org.testcontainers` package.
