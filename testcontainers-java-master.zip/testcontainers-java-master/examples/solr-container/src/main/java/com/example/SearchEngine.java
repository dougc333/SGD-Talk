package com.example;

public interface SearchEngine {

    public SearchResult search(String term);
}
