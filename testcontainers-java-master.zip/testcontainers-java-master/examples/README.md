# testcontainers-java-examples

> Practical examples of using Testcontainers.

The code in this repository accompanies the following blog posts:

* [JUnit integration testing with Docker and Testcontainers](https://rnorth.org/junit-integration-testing-with-docker-and-testcontainers)
* [Fun with Disque, Java and Spinach](https://rnorth.org/fun-with-disque-java-and-spinach)
* [Better JUnit Selenium testing with Docker and Testcontainers](https://rnorth.org/better-junit-selenium-testing-with-docker-and-testcontainers)
