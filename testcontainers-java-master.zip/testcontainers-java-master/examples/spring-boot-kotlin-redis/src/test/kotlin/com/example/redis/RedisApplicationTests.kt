package com.example.redis

import org.junit.Test

class RedisApplicationTests : AbstractIntegrationTest() {

    @Test
    fun contextLoads() {
    }

}
