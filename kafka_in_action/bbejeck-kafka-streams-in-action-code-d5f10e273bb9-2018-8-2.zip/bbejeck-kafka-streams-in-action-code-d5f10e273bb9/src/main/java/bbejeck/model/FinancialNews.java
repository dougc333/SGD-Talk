package bbejeck.model;

/**
 * User: Bill Bejeck
 * Date: 3/21/17
 * Time: 11:14 PM
 */
public class FinancialNews {

    private String industry;
    private String news;

    public String getIndustry() {
        return industry;
    }

    public String getNews() {
        return news;
    }
}
