The snippet files in this directory are extracted from source files elsewhere
in this repository by an automated process.  Do not make changes to snippets
yourself; your changes will likely be lost in the not-so-distant future.