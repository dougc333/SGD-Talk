def layer_function() -> str:
    """
    Layer helper function
    """
    return "Hello From Helper Layer!"
