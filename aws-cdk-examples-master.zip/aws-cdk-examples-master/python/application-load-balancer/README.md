# ALB

![Detailed diagram](diagram.png)
