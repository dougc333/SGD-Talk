def main(event, context):
    print("I'm running!")
