# API Gateway + CORS + Lambda

![Detailed diagram](diagram.png)
