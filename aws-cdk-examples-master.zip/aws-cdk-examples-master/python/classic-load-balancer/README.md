# Classic Load Balancer

![Detailed diagram](diagram.png)
