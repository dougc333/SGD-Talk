import React from 'react'
export default (props) => (
    <div className="container-fluid">
        <div className="row">
            <div className="col-lg-12">
                <h1 className="page-header">Blank</h1>
                <p>My blank app</p>
            </div>
        </div>
    </div>
)