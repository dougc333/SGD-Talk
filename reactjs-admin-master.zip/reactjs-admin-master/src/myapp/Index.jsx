import React from 'react'
export default (props) => (
    <div className="container-fluid">
        <div className="row">
            <div className="col-lg-12">
                <h1 className="page-header">Index Page</h1>
                <p>My dashboard</p>
            </div>
        </div>
    </div>
)