import React from 'react'
import './loader.scss'

export default (props) => (
    <div className="loader">
        <div className="spinner"></div>
    </div>
)