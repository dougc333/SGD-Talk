#!/bin/bash

mongod --config /usr/local/etc/mongod.conf --fork

