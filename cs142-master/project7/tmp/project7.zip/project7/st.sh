#!/bin/bash

brew services start mongodb-community@4.2