<?php
namespace Vanderbilt\REDCap\Classes\Parcel\Exceptions;

use Exception;

class NotificationNotSentException extends Exception {}