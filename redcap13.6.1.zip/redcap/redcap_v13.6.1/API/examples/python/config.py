
config = dict(
    api_super_token = 'ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234',
    api_token       = '12340DCA87C457B6FABC8147AD7E4790',
    api_url         = 'http://example.com/redcap/api/'
)
